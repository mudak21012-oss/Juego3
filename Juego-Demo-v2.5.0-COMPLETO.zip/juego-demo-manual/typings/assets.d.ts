declare module "*.png";
declare module "*.fnt";
