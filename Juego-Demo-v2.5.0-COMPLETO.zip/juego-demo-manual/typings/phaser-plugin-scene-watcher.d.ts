declare module "phaser-plugin-scene-watcher";
