import CasualEncounterPNG from "../../assets/annaanthropy/CasualEncounter.png";
import CasualEncounterFNT from "../../assets/annaanthropy/CasualEncounter.fnt";

export default {
  default: [CasualEncounterPNG, CasualEncounterFNT]
};
