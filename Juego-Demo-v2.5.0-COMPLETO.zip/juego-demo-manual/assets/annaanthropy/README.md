Credit: https://w.itch.io/world-of-fonts
