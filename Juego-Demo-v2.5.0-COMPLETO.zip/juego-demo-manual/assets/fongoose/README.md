The files in this directory are from Fongoose's [Rogue Dungeon Tileset](https://fongoose.itch.io/rogue-dungeon-tileset-16x16) and are used with permission.

If you like this tileset, please purchase a copy from the above link rather than copying them from this project.
